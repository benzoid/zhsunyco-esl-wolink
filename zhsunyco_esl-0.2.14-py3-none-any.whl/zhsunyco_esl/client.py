import asyncio
import logging
from typing import Union
from bleak import BleakClient, BleakScanner
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from .models import LabelConfig, DEFAULT_CONFIG
from .image import process_image
from .protocol import compress_wolink_blocks

_LOGGER = logging.getLogger(__name__)

# WOLINK AES-128 authentication key
WOLINK_AES_KEY = bytes([
    0x9B, 0x60, 0x9F, 0x28, 0xBC, 0x49, 0xE2, 0x57,
    0x29, 0xBD, 0x7B, 0x8D, 0xF2, 0x2B, 0x44, 0x20,
])

# WOLINK characteristic UUIDs (per BLE Display API doc)
WOLINK_AUTH_CHAR          = "33323032-4c53-4545-4c42-4b4e494c4f57"  # Security auth (read nonce, write AES-128)
WOLINK_DATA_CHAR          = "31323032-4c53-4545-4c42-4b4e494c4f57"  # Command data (image + refresh)
WOLINK_STATUS_NOTIFY_CHAR = "34323032-4c53-4545-4c42-4b4e494c4f57"  # Status notifications (BUSY/ERR)
WOLINK_BATTERY_CHAR       = "35323032-4c53-4545-4c42-4b4e494c4f57"  # Battery voltage (2B mV)
WOLINK_INFO_CHAR          = "32323032-4c53-4545-4c42-4b4e494c4f57"  # Version info (PID/App/HW/Disp)


class ZhsunycoClient:
    large_payload = 20000

    def __init__(self, address: Union[str, "BLEDevice"], config: LabelConfig = DEFAULT_CONFIG, client_factory=None):
        if isinstance(address, str):
            self.mac_address = address
            self._ble_device = None
        else:
            self._ble_device = address
            self.mac_address = address.address
        self.config = config
        self.client = None
        self._client_factory = client_factory

    def set_client(self, client):
        """Set a pre-connected BleakClient (e.g. from establish_connection)."""
        self.client = client

    async def initialize(self):
        """Authenticate on an already-connected client."""
        await self._wolink_authenticate()

    async def connect(self, max_attempts=3):
        last_error = None
        for attempt in range(1, max_attempts + 1):
            try:
                if attempt > 1:
                    _LOGGER.info("Retry %d/%d...", attempt, max_attempts)
                    await asyncio.sleep(2.0)

                if self._ble_device:
                    device = self._ble_device
                    _LOGGER.info("Using provided BLEDevice: %s", device.address)
                else:
                    _LOGGER.info("Scanning for %s...", self.mac_address)
                    device = await BleakScanner.find_device_by_address(self.mac_address, timeout=120.0)
                    if not device:
                        raise Exception(f"Device {self.mac_address} not found within 120s")

                _LOGGER.info("Connecting...")
                self.client = self._client_factory(device) if self._client_factory else BleakClient(device, timeout=60.0)
                await self.client.connect()
                _LOGGER.info("Connected")
                await asyncio.sleep(1.0)

                # Negotiate higher MTU for WOLINK devices (need large writes)
                try:
                    mtu = self.client.mtu_size
                    if mtu < 250:
                        _LOGGER.debug("MTU: %d, requesting 512...", mtu)
                        # On BlueZ, MTU is negotiated automatically on first write
                except Exception:
                    pass

                await self._wolink_authenticate()
                return  # success

            except Exception as e:
                last_error = e
                _LOGGER.warning("Connection failed: %s", e)
                # Clean up failed connection
                if self.client:
                    try:
                        await self.client.disconnect()
                    except Exception:
                        pass
                    self.client = None

        raise Exception(f"Failed to connect after {max_attempts} attempts: {last_error}")

    async def _wolink_authenticate(self):
        """Read nonce from auth characteristic, AES-128-ECB encrypt, write back."""
        _LOGGER.info("Authenticating...")
        nonce = await self.client.read_gatt_char(WOLINK_AUTH_CHAR)
        _LOGGER.debug("Nonce: %s", nonce.hex())

        cipher = Cipher(algorithms.AES(WOLINK_AES_KEY), modes.ECB())
        encryptor = cipher.encryptor()
        encrypted = encryptor.update(bytes(nonce)) + encryptor.finalize()
        _LOGGER.debug("Encrypted: %s", encrypted.hex())

        await self.client.write_gatt_char(WOLINK_AUTH_CHAR, encrypted, response=True)
        _LOGGER.info("Authenticated")
        await asyncio.sleep(0.5)

    async def disconnect(self):
        if self.client:
            await self.client.disconnect()
            _LOGGER.info("Disconnected")

    async def send_image_planes(self, plane_bw, plane_red, plane_yellow=None, *, compress=True):
        if plane_yellow is None:
            plane_yellow = [0] * len(plane_bw)

        if not self.client or not self.client.is_connected:
            await self.connect()

        await self._wolink_send_image(plane_bw, plane_red, plane_yellow, compress=compress)

    async def _wolink_send_image(self, plane_bw, plane_red, plane_yellow, compress=True):
        """Send image using WOLINK protocol.

        From BLE capture analysis:
        - Image data is written to char 35323032 (not 31323032)
        - Format: 00 a5 00 00 00 00 + compressed_data (single write for small images)
        - For larger data: chunked with 00 a5 + 4-byte LE offset + data
        - Refresh command: 02 a5 d4 00 00 00
        - Success notification on char 34323032: ff 00 00 00 00 00 00 00
        """
        width = self.config.width   # 296 (physical width)
        height = self.config.height  # 128 (physical height)

        # BWRY e-ink: 2 bits per pixel, 4 pixels per byte, MSB first
        # Color map: 00=Black, 01=White, 10=Yellow, 11=Red
        # Buffer: 296 rows × 128 cols (rotated 90° from physical display)
        # Mapping: buffer(row, col) = image(width-1-row, col)
        # Some devices (e.g., 2.9") have an inherent horizontal mirror
        if self.config.mirror:
            def flip_plane_h(plane):
                flipped = list(plane)
                for y in range(height):
                    for x in range(width // 2):
                        a = y * width + x
                        b = y * width + (width - 1 - x)
                        flipped[a], flipped[b] = flipped[b], flipped[a]
                return flipped

            plane_bw = flip_plane_h(plane_bw)
            plane_red = flip_plane_h(plane_red)
            plane_yellow = flip_plane_h(plane_yellow)

        if self.config.row_major:
            buf_h = height   # 480 rows (standard raster scan)
            buf_w = width    # 800 cols
        else:
            buf_h = width    # 296 rows (column-major scan)
            buf_w = height   # 128 cols
        raw = bytearray()

        for row in range(buf_h):
            for col_group in range(buf_w // 4):  # 4 pixels per byte at 2bpp
                byte = 0
                for p in range(4):
                    col = col_group * 4 + p

                    if self.config.row_major:
                        orig_x = col
                        orig_y = row
                    elif self.config.rotate_cw:
                        orig_x = width - 1 - row
                        orig_y = col
                    else:
                        orig_x = row
                        orig_y = height - 1 - col

                    # Determine 2-bit color value: 00=Black, 01=White, 10=Yellow, 11=Red
                    idx = orig_y * width + orig_x
                    bw = plane_bw[idx]
                    red = plane_red[idx]
                    yellow = plane_yellow[idx]
                    if bw:
                        color = 0b00      # Black
                    elif red:
                        color = 0b11      # Red
                    elif yellow:
                        color = 0b10      # Yellow
                    else:
                        color = 0b01      # White

                    byte |= (color << (6 - p * 2))
                raw.append(byte)

        raw_size = len(raw)
        _LOGGER.info("Image data: %d bytes (%dx%d, 2bpp rotated)", raw_size, width, height)

        # Optionally compress using WOLINK block deflate format
        if compress:
            payload = compress_wolink_blocks(bytes(raw))
            refresh_opcode = 0x02  # block-compressed
            _LOGGER.info(
                "Compressed %d -> %d bytes (%.0f%%)",
                raw_size, len(payload), 100 * len(payload) / raw_size,
            )
        else:
            payload = bytes(raw)
            refresh_opcode = 0x01  # uncompressed

        total_size = len(payload)

        # Enable notifications on status characteristic (34323032)
        # API doc: byte 0 = BUSY (0/1), byte 1 = ERR (0-5)
        # Observed: 0xFF at byte 0 signals refresh complete
        notify_event = asyncio.Event()
        self.last_error_code: int = 0

        def handle_notify(s, d):
            _LOGGER.debug("Notify: %s", d.hex())
            if d[0] == 0xFF:
                _LOGGER.info("Refresh success")
                self.last_error_code = 0
            elif len(d) >= 2 and d[1] != 0:
                self.last_error_code = d[1]
                _LOGGER.warning("Device error: code %d", d[1])
            notify_event.set()

        await self.client.start_notify(WOLINK_STATUS_NOTIFY_CHAR, handle_notify)
        await asyncio.sleep(0.3)

        # Send image data in chunks: 00 a5 + 4-byte LE offset + data
        # BlueZ handles writes larger than MTU via ATT Prepared Writes
        chunk_size = 200

        offset = 0
        total_chunks = (total_size + chunk_size - 1) // chunk_size

        _LOGGER.info("Sending %d data chunks (%dB/chunk)...", total_chunks, chunk_size)
        for i in range(total_chunks):
            chunk = payload[offset:offset + chunk_size]
            cmd = bytearray([0x00, 0xA5])
            cmd.extend(offset.to_bytes(4, 'little'))
            cmd.extend(chunk)

            for attempt in range(3):
                try:
                    await self.client.write_gatt_char(WOLINK_DATA_CHAR, bytes(cmd), response=True)
                    break
                except Exception as e:
                    _LOGGER.warning("Chunk %d retry %d: %s", i + 1, attempt + 1, e)
                    if attempt < 2:
                        await asyncio.sleep(0.5)
            else:
                raise RuntimeError(
                    f"Failed to send chunk {i + 1}/{total_chunks} after 3 attempts — aborting transfer"
                )
            offset += len(chunk)

            if (i + 1) % 50 == 0 or (i + 1) == total_chunks:
                _LOGGER.debug("Sent %d/%d (%d/%d bytes)", i + 1, total_chunks, offset, total_size)
            await asyncio.sleep(0.03)

        # Refresh command: 01 a5 = uncompressed, 02 a5 = block-compressed
        _LOGGER.info("Sending refresh command (opcode=0x%02X)...", refresh_opcode)
        refresh_cmd = bytearray([refresh_opcode, 0xA5])
        refresh_cmd.extend(total_size.to_bytes(4, 'little'))
        await self.client.write_gatt_char(WOLINK_DATA_CHAR, bytes(refresh_cmd), response=True)
        _LOGGER.debug("Refresh: %s (size=%d)", refresh_cmd.hex(), total_size)

        # Wait for display refresh notification (or timeout after 30s/60s)
        _LOGGER.info("Waiting for display refresh...")
        try:
            refresh_timeout = 60.0 if raw_size > ZhsunycoClient.large_payload else 30.0
            await asyncio.wait_for(notify_event.wait(), timeout=refresh_timeout)
        except asyncio.TimeoutError:
            _LOGGER.warning("Timed out waiting for refresh notification")

        try:
            if self.client.is_connected:
                await self.client.stop_notify(WOLINK_STATUS_NOTIFY_CHAR)
        except Exception:
            pass

    async def send_image_file(self, image_path: str, color_mode: str = "BWRY", dither: bool = False, compress: bool = True):
        plane_bw, plane_red, plane_yellow = process_image(image_path, self.config, color_mode, dither=dither)
        await self.send_image_planes(plane_bw, plane_red, plane_yellow, compress=compress)
