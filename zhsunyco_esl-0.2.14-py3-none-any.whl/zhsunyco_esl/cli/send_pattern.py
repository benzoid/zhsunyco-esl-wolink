import asyncio
import click
from PIL import Image, ImageDraw
from zhsunyco_esl import ZhsunycoClient
from zhsunyco_esl.image import quantize_image
from zhsunyco_esl.cli._common import device_options, get_config, get_device_profile


@click.command()
@click.version_option()
@click.option('--mac', required=True, help='MAC address of the label')
@device_options
def main(mac, device):
    """Sends a generated test pattern to the Zhsunyco label."""

    profile = get_device_profile(device)
    config = get_config(device)
    width, height, color = config.width, config.height, profile['color']

    print(f"Generating test pattern ({width}x{height}, {color})...")
    img = Image.new("RGB", (width, height), "white")
    draw = ImageDraw.Draw(img)

    # Stripes: Black, Red, Yellow, Black
    draw.rectangle([20, 0, 60, height], fill="black")
    draw.rectangle([80, 0, 120, height], fill="red")
    if color == 'BWRY':
        draw.rectangle([120, 0, 160, height], fill="yellow")
    draw.rectangle([180, 0, 220, height], fill="black")

    # Square in bottom right
    draw.rectangle([width - 20, height - 20, width, height], fill="black")

    client = ZhsunycoClient(mac, config=config)
    plane_bw, plane_red, plane_yellow = quantize_image(img, width, height, color_mode=color, dither=False)

    try:
        asyncio.run(client.send_image_planes(plane_bw, plane_red, plane_yellow))
    except Exception as e:
        print(f"Error: {e}")
        ctx = click.get_current_context()
        ctx.exit(1)


if __name__ == "__main__":
    main()
