import click
from PIL import ImageFont
from zhsunyco_esl.models import DEVICES, LabelConfig

_FONT_PATHS = [
    "/usr/share/fonts/liberation-sans-fonts/LiberationSans-Bold.ttf",
    "/usr/share/fonts/liberation-sans-fonts/LiberationSans-Regular.ttf",
    "arial.ttf",
    "/usr/share/fonts/open-sans/OpenSans-Semibold.ttf",
]


def load_font(size: int) -> ImageFont.FreeTypeFont:
    """Load a TrueType font at the given size, trying common system paths."""
    for path in _FONT_PATHS:
        try:
            return ImageFont.truetype(path, size)
        except (IOError, OSError):
            continue
    return ImageFont.load_default()


def fit_text(draw, text, font_size, max_width, min_size=8):
    """Shrink font until text fits within max_width; truncate with '…' at min_size."""
    for size in range(font_size, min_size - 1, -1):
        font = load_font(size)
        bbox = draw.textbbox((0, 0), text, font=font)
        if bbox[2] - bbox[0] <= max_width:
            return font, text
    # At min_size still too wide — truncate with ellipsis
    font = load_font(min_size)
    for end in range(len(text) - 1, 0, -1):
        truncated = text[:end] + "…"
        bbox = draw.textbbox((0, 0), truncated, font=font)
        if bbox[2] - bbox[0] <= max_width:
            return font, truncated
    return font, "…"


def device_options(f):
    """Common CLI options for device selection."""
    f = click.option('--device', default='290', type=click.Choice(list(DEVICES.keys())),
                     help='Device type (290=2.9", 350=3.5", 750=7.5")')(f)
    return f


def get_config(device: str) -> LabelConfig:
    """Get LabelConfig from device profile key."""
    return LabelConfig.from_device(device)


def get_device_profile(device: str) -> dict:
    """Get the full device profile dict."""
    return DEVICES[device]
