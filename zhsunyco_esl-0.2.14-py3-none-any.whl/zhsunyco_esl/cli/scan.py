import asyncio
import os
import sys
import click
from bleak import BleakScanner

from zhsunyco_esl.models import SERVICE_UUIDS, KNOWN_MAC_PREFIX, KNOWN_NAME_PREFIX

HEADER = f"{'MAC Address':<20} {'RSSI':>6}  {'Name'}"
SEPARATOR = "-" * 54


def _term_width():
    try:
        return os.get_terminal_size().columns
    except OSError:
        return 80


def _is_zhsunyco(device, adv):
    """Detect Zhsunyco labels by service UUID, MAC prefix, or name prefix."""
    if adv.service_uuids:
        uuids = [u.lower() for u in adv.service_uuids]
        if any(uuid in uuids for uuid in SERVICE_UUIDS):
            return True
    if device.address.upper().startswith(KNOWN_MAC_PREFIX.upper()):
        return True
    name = device.name or adv.local_name or ""
    if name.upper().startswith(KNOWN_NAME_PREFIX):
        return True
    return False


def _format_device(device, adv):
    name = device.name or adv.local_name or "(unknown)"
    rssi = adv.rssi if adv.rssi is not None else "?"
    return f"{device.address:<20} {rssi:>6}  {name}"


def _pad(text):
    """Pad text to terminal width so redraws fully overwrite previous lines."""
    width = _term_width()
    return text.ljust(width)[:width]


def _redraw(found, remaining, all_devices):
    label = "BLE devices" if all_devices else "Zhsunyco labels"
    status = f"Scanning... {remaining:>3}s remaining | {len(found)} {label} found"
    lines = [_pad(status)]
    if found:
        lines.append("")
        lines.append(_pad(HEADER))
        lines.append(_pad(SEPARATOR))
        for device, adv in found.values():
            lines.append(_pad(_format_device(device, adv)))

    # Move cursor up to overwrite previous output, clear screen below
    total_lines = getattr(_redraw, "_prev_lines", 0)
    if total_lines > 0:
        sys.stdout.write(f"\033[{total_lines}A")
    sys.stdout.write("\033[J")
    sys.stdout.write("\n".join(lines))
    sys.stdout.flush()
    _redraw._prev_lines = len(lines)


async def _scan(timeout: float, all_devices: bool):
    found = {}

    def on_detection(device, adv):
        if device.address in found:
            return
        if not all_devices and not _is_zhsunyco(device, adv):
            return
        found[device.address] = (device, adv)

    scanner = BleakScanner(detection_callback=on_detection)
    await scanner.start()

    remaining = int(timeout)
    _redraw._prev_lines = 0
    while remaining > 0:
        _redraw(found, remaining, all_devices)
        await asyncio.sleep(1)
        remaining -= 1

    await scanner.stop()

    # Final redraw
    label = "BLE devices" if all_devices else "Zhsunyco labels"
    total_lines = getattr(_redraw, "_prev_lines", 0)
    if total_lines > 0:
        sys.stdout.write(f"\033[{total_lines}A")
    sys.stdout.write("\033[J")

    if not found:
        if not all_devices:
            print("No Zhsunyco labels found. Use --all to show all BLE devices.")
        else:
            print("No BLE devices found.")
        return

    print(f"Scan complete. {len(found)} {label} found.\n")
    print(HEADER)
    print(SEPARATOR)
    for device, adv in found.values():
        print(_format_device(device, adv))


@click.command()
@click.option("--timeout", default=30.0, help="Scan duration in seconds")
@click.option("--all", "all_devices", is_flag=True, help="Show all BLE devices, not just Zhsunyco labels")
def main(timeout, all_devices):
    """Scan for nearby Zhsunyco BLE e-ink labels."""
    asyncio.run(_scan(timeout, all_devices))


if __name__ == "__main__":
    main()
