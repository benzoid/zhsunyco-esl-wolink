import asyncio
import click
from zhsunyco_esl import ZhsunycoClient
from zhsunyco_esl.cli._common import device_options, get_config, get_device_profile


@click.command()
@click.version_option()
@click.option('--mac', required=True, help='MAC address of the label')
@click.option('--image', required=True, type=click.Path(exists=True), help='Path to image file')
@device_options
@click.option('--dither', is_flag=True, help='Enable Floyd-Steinberg dithering (better for photos/gradients)')
def main(mac, image, device, dither):
    """Sends an image to the Zhsunyco label, resizing and quantizing colors."""

    profile = get_device_profile(device)
    config = get_config(device)
    client = ZhsunycoClient(mac, config=config)

    print(f"Sending image {image} to {mac} ({profile['name']}, dither={'on' if dither else 'off'})...")
    try:
        asyncio.run(client.send_image_file(image, color_mode=profile['color'], dither=dither))
    except Exception as e:
        print(f"Error ({type(e).__name__}): {e}")
        import traceback
        traceback.print_exc()
        ctx = click.get_current_context()
        ctx.exit(1)


if __name__ == "__main__":
    main()
